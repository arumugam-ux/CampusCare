CAMPUSCARE - FLASK PROJECT

FEATURES
- Student complaint form (water purifier, bus/transport, facilities, etc.)
- Department, year and section fields
- Lost & Found report board
- Upcoming events and campus notices
- Admin login and dashboard
- Admin can update complaint status, add/delete events, and add/delete notices
- SQLite database is created automatically

SETUP (Windows)
1. Extract this ZIP into a folder.
2. Open that folder in VS Code or PowerShell.
3. Run: python -m pip install -r requirements.txt
4. Run: python app.py
5. Open http://127.0.0.1:5000 in your browser.

ADMIN DEMO LOGIN
Username: admin
Password: admin12345

IMPORTANT
This is a student demo project. Before real deployment, change app.secret_key and replace
the demo admin credentials with secure authentication. Do not use real private data in a public demo.
