from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from functools import wraps
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB_PATH = Path(__file__).with_name("campuscare.db")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS complaints (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL, department TEXT, year TEXT, section TEXT,
        category TEXT NOT NULL, description TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Pending',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS lost_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item_name TEXT NOT NULL, description TEXT, location TEXT,
        contact TEXT NOT NULL, item_status TEXT NOT NULL DEFAULT 'Lost',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL, event_date TEXT, department TEXT, details TEXT
    );
    CREATE TABLE IF NOT EXISTS notices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL, details TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    """)
    if conn.execute("SELECT COUNT(*) FROM events").fetchone()[0] == 0:
        conn.execute("INSERT INTO events (title,event_date,department,details) VALUES (?,?,?,?)",
                     ("Campus Innovation Day", "2026-11-05", "All Departments", "Project demonstrations and student activities."))
    if conn.execute("SELECT COUNT(*) FROM notices").fetchone()[0] == 0:
        conn.execute("INSERT INTO notices (title,details) VALUES (?,?)",
                     ("Welcome to CampusCare", "Use this portal to submit campus complaints and report lost or found items."))
    conn.commit()
    conn.close()

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("admin"):
            flash("Please log in as admin first.", "warning")
            return redirect(url_for("admin_login"))
        return fn(*args, **kwargs)
    return wrapper

@app.route("/")
def index():
    conn = db()
    events = conn.execute("SELECT * FROM events ORDER BY event_date IS NULL, event_date LIMIT 6").fetchall()
    notices = conn.execute("SELECT * FROM notices ORDER BY id DESC LIMIT 6").fetchall()
    counts = {
        "complaints": conn.execute("SELECT COUNT(*) FROM complaints").fetchone()[0],
        "lost": conn.execute("SELECT COUNT(*) FROM lost_items WHERE item_status='Lost'").fetchone()[0],
        "events": conn.execute("SELECT COUNT(*) FROM events").fetchone()[0],
    }
    conn.close()
    return render_template("index.html", events=events, notices=notices, counts=counts)

@app.route("/complaint", methods=["GET", "POST"])
def complaint():
    if request.method == "POST":
        form = request.form
        required = ["name", "category", "description"]
        if not all(form.get(k, "").strip() for k in required):
            flash("Please fill in your name, category, and complaint details.", "danger")
            return redirect(url_for("complaint"))
        conn = db()
        conn.execute("""INSERT INTO complaints (name,department,year,section,category,description)
                        VALUES (?,?,?,?,?,?)""",
                     (form["name"].strip(), form.get("department","").strip(),
                      form.get("year","").strip(), form.get("section","").strip(),
                      form["category"], form["description"].strip()))
        conn.commit()
        conn.close()
        flash("Complaint submitted successfully. Save your complaint ID if shown by admin.", "success")
        return redirect(url_for("complaint"))
    return render_template("complaint.html")

@app.route("/lost-found", methods=["GET", "POST"])
def lost_found():
    conn = db()
    if request.method == "POST":
        form = request.form
        if not form.get("item_name","").strip() or not form.get("contact","").strip():
            flash("Item name and contact are required.", "danger")
        else:
            conn.execute("""INSERT INTO lost_items (item_name,description,location,contact,item_status)
                            VALUES (?,?,?,?,?)""",
                         (form["item_name"].strip(), form.get("description","").strip(),
                          form.get("location","").strip(), form["contact"].strip(),
                          form.get("item_status","Lost")))
            conn.commit()
            flash("Lost & Found report added.", "success")
        conn.close()
        return redirect(url_for("lost_found"))
    items = conn.execute("SELECT * FROM lost_items ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("lost_found.html", items=items)

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if username == "admin" and password == "admin12345":
            session["admin"] = True
            flash("Admin login successful.", "success")
            return redirect(url_for("admin_dashboard"))
        flash("Incorrect username or password.", "danger")
    return render_template("admin_login.html")

@app.route("/admin/logout")
def admin_logout():
    session.pop("admin", None)
    flash("Logged out.", "info")
    return redirect(url_for("index"))

@app.route("/admin")
@admin_required
def admin_dashboard():
    conn = db()
    complaints = conn.execute("SELECT * FROM complaints ORDER BY id DESC").fetchall()
    items = conn.execute("SELECT * FROM lost_items ORDER BY id DESC").fetchall()
    events = conn.execute("SELECT * FROM events ORDER BY id DESC").fetchall()
    notices = conn.execute("SELECT * FROM notices ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("admin.html", complaints=complaints, items=items, events=events, notices=notices)

@app.route("/admin/complaint/<int:item_id>/status", methods=["POST"])
@admin_required
def complaint_status(item_id):
    status = request.form.get("status", "Pending")
    if status not in ["Pending", "In Progress", "Resolved"]:
        status = "Pending"
    conn = db()
    conn.execute("UPDATE complaints SET status=? WHERE id=?", (status, item_id))
    conn.commit()
    conn.close()
    flash("Complaint status updated.", "success")
    return redirect(url_for("admin_dashboard") + "#complaints")

@app.route("/admin/event/add", methods=["POST"])
@admin_required
def add_event():
    f = request.form
    if f.get("title","").strip():
        conn = db()
        conn.execute("INSERT INTO events (title,event_date,department,details) VALUES (?,?,?,?)",
                     (f["title"].strip(), f.get("event_date",""), f.get("department","").strip(), f.get("details","").strip()))
        conn.commit()
        conn.close()
        flash("Event added.", "success")
    return redirect(url_for("admin_dashboard") + "#events")

@app.route("/admin/event/<int:item_id>/delete", methods=["POST"])
@admin_required
def delete_event(item_id):
    conn = db()
    conn.execute("DELETE FROM events WHERE id=?", (item_id,))
    conn.commit()
    conn.close()
    flash("Event deleted.", "info")
    return redirect(url_for("admin_dashboard") + "#events")

@app.route("/admin/notice/add", methods=["POST"])
@admin_required
def add_notice():
    f = request.form
    if f.get("title","").strip() and f.get("details","").strip():
        conn = db()
        conn.execute("INSERT INTO notices (title,details) VALUES (?,?)", (f["title"].strip(), f["details"].strip()))
        conn.commit()
        conn.close()
        flash("Notice added.", "success")
    return redirect(url_for("admin_dashboard") + "#notices")

@app.route("/admin/notice/<int:item_id>/delete", methods=["POST"])
@admin_required
def delete_notice(item_id):
    conn = db()
    conn.execute("DELETE FROM notices WHERE id=?", (item_id,))
    conn.commit()
    conn.close()
    flash("Notice deleted.", "info")
    return redirect(url_for("admin_dashboard") + "#notices")

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
